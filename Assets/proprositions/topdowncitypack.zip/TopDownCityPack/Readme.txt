
---Hi! I'm FisherG, the one who made these assets. ----


-All of this content is free to manipulate, and use in whatever manner you please.
One exception, you cannot redistribute this art as your own.


-Sprites are on a 12x12 grid. Human sprites I recommend to leave at a 26x26 resolution for whatever animations you choose to create. 2 example sprites of an idle and walking animation are given.


-Any recommendations for the asset pack? Leave a comment on the OpenGameArt Page, the Itchio page, or DM me on twitter.


---Contact---
@TheFish523 - Twitter. DMs open. 
FisherG - Itch.io
FisherG - OpenGameArt. DMs open. 